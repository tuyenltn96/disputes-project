import { AppComponent } from './app/app.component';

export * from './app/app.component';

export const containers: Array<any> = [
    AppComponent
];
