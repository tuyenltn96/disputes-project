import { DisputesComponent } from './disputes/disputes.component';
import {CreateDialogComponent} from './create-dialog/create-dialog.component';
export const containers: any[] = [
    DisputesComponent
];

export * from './disputes/disputes.component';
export * from './create-dialog/create-dialog.component';