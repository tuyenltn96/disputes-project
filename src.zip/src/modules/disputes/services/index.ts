import { DisputesService } from './disputes.service';

export const service: any[] = [DisputesService];

export * from './disputes.service';
