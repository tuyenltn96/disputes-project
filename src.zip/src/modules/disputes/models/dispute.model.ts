
export interface Dispute {
    id?: string;
    name?: string;
    date?: string;
}
