import { Injectable } from '@angular/core';

import { Effect, Actions, toPayload } from '@ngrx/effects';
import { of } from 'rxjs/observable/of';
import { Observable } from 'rxjs/Observable';
import { map, switchMap, catchError } from 'rxjs/operators';

import { Action } from '@ngrx/store';

import * as fromRoot from '../../../app/_store';
import * as disputeActions from '../actions/disputes.action';
import * as fromServices from '../../services';
import * as fromComponents from '../../components';


@Injectable()
export class DisputesEffects {
    constructor(
        private actions$: Actions,
        private disputeService: fromServices.DisputesService
    ) { }
    @Effect()
    loadDisputes$ = this.actions$
        .ofType(disputeActions.LOAD_DISPUTES)
        .pipe(
        switchMap(() => {
            return this.disputeService
                .getDisputes()
                .pipe(
                map(disputes => new disputeActions.LoadDisputesSuccess(disputes)),
                catchError(error => of(new disputeActions.LoadDisputesFail(error)))
                );
        })
        );
    @Effect()
    removeDispute$ = this.actions$
        .ofType(disputeActions.REMOVE_DISPUTE)
        .pipe(
        map((action: disputeActions.RemoveDispute) => action.payload),
        switchMap(dispute => {
            return this.disputeService
                .removeDispute(dispute)
                .pipe(
                map(() => new disputeActions.RemoveDisputeSuccess(dispute)),
                catchError(error => of(new disputeActions.RemoveDisputeFail(error)))
                );
        })
        );

    @Effect()
    updateDispute$ = this.actions$
        .ofType(disputeActions.UPDATE_DISPUTE)
        .pipe(
        map((action: disputeActions.UpdateDispute) => action.payload),
        switchMap(dispute => {
            return this.disputeService
                .updateDispute(dispute)
                .pipe(
                map(disputes => new disputeActions.UpdateDisputeSuccess(disputes)),
                catchError(error => of(new disputeActions.UpdateDisputeFail(error)))
                );
        })
        );
}
