import { DisputesEffects } from './disputes.effect';

export const effects: any[] = [DisputesEffects];

export * from './disputes.effect';
