import { DisputeItemComponent } from './dispute-item/dispute-item.component';
import {DeleteDialogComponent} from './delete-dialog/delete-dialog.component';
import {EditDialogComponent} from './edit-dialog/edit-dialog.component';
export const components: Array<any> = [
    DisputeItemComponent,
    DeleteDialogComponent,
    EditDialogComponent
];

export * from './dispute-item/dispute-item.component';
export * from './delete-dialog/delete-dialog.component';
export * from './edit-dialog/edit-dialog.component';


